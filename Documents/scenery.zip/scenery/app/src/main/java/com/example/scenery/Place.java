package com.example.scenery;

public class Place {
    private String name;
    private String description;
    private int position;

    public Place(String name, String description, int position) {
        this.name = name;
        this.description = description;
        this.position = position;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
    public int getPosition() {
        return position;
    }
}