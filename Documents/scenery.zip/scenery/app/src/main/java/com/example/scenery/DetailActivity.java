package com.example.scenery;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {
    private int[] pictures = {R.drawable.yu,R.drawable.ali,R.drawable.snow,R.drawable.hehuan,R.drawable.nanhu,R.drawable.tai_lu_g,R.drawable.yun_fuon,R.drawable.yun_ja_nain,R.drawable.seven};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ImageView imageView = findViewById(R.id.imageView);
        TextView descriptionTextView = findViewById(R.id.place_description);
        Button openMapButton = findViewById(R.id.open_map_button);

        Intent intent = getIntent();
        String placeName = intent.getStringExtra("place_name");
        String placeDescription = intent.getStringExtra("place_description");
        int position = intent.getIntExtra("position", -1);

        setTitle(placeName);
        descriptionTextView.setText(placeDescription);

        if (position != -1 && position < pictures.length) { // 检查position是否有效
            imageView.setImageResource(pictures[position]);
        }
        openMapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 使用地點名稱構建 Google 地圖的搜尋 URL
                String mapUrl = "https://www.google.com/maps/search/?api=1&query=" + Uri.encode(placeName);

                // 創建一個 Intent 以打開網頁瀏覽器並顯示 Google 地圖網頁版
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(mapUrl));

                // 檢查設備上是否有適合的應用程序處理這個 Intent
                if (mapIntent.resolveActivity(getPackageManager()) != null) {
                    // 如果有，啟動 Intent
                    startActivity(mapIntent);
                } else {
                    // 如果沒有，顯示提示訊息或者提供其他替代方案
                    Toast.makeText(DetailActivity.this, "未找到適合的應用程序", Toast.LENGTH_SHORT).show();
                }
            }

        });
        // 啟用ActionBar的返回按鈕
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // 處理ActionBar的返回按鈕行為
        if (item.getItemId() == android.R.id.home) {
            finish(); // 結束當前Activity，返回上一頁
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}