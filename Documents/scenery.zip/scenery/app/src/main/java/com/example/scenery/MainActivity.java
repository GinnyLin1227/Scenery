package com.example.scenery;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private PlaceAdapter placeAdapter;
    private List<Place> placeList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        placeList = new ArrayList<>();
        placeList.add(new Place("玉山", "台灣最高峰，需要具備豐富登山經驗的登山者前往",0));
        placeList.add(new Place("阿里山", "以日出、雲海和神木聞名，是台灣著名的觀光景點之一",1));
        placeList.add(new Place("雪山", "位於中央山脈，擁有優美的高山湖泊，是登山者和露營者的熱門景點",2));
        placeList.add(new Place("合歡山", "位於中央山脈，是台灣知名的觀星地點，也有多樣的高山植物",3));
        placeList.add(new Place("南湖大山", "位於南投縣，是南投地區的主要山脈，有許多登山步道供遊客探索",4));
        placeList.add(new Place("太魯閣國家公園", "著名的峽谷景觀，擁有壯觀的峭壁和瀑布，吸引著眾多遊客和登山愛好者",5));
        placeList.add(new Place("雲峰林道", "位於台中市和南投縣交界處，是台灣著名的觀景景點，可以眺望壯麗的山脈風景",6));
        placeList.add(new Place("雲嘉南山脈", "橫跨雲林、嘉義和台南，擁有多樣的地形與生態，是生物多樣性豐富的區域",7));
        placeList.add(new Place("七星山", "位於台北市附近，是許多都市登山者經常前往的山岳，也是眺望台北市夜景的絕佳地點之一",8));
        // 添加更多景點...

        placeAdapter = new PlaceAdapter(placeList, new PlaceAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Place place) {
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("place_name", place.getName());
                intent.putExtra("place_description", place.getDescription());
                intent.putExtra("position", place.getPosition());
                startActivity(intent);
            }
        });
        recyclerView.setAdapter(placeAdapter);
    }
}